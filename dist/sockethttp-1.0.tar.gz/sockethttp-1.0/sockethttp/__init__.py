# coding: utf-8

from . import get
__version__ = "1.0"
